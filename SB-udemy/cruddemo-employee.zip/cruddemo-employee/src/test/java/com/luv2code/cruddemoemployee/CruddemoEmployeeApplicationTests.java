package com.luv2code.cruddemoemployee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CruddemoEmployeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
