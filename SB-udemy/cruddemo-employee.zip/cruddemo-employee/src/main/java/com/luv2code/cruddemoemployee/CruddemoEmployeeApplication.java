package com.luv2code.cruddemoemployee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CruddemoEmployeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CruddemoEmployeeApplication.class, args);
	}

}
